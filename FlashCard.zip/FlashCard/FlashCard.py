import random

def read_flashcards_from_file(file_path):
    flashcards = {}
    with open(file_path, 'r') as file:
        for line in file:
            question, answer = line.strip().split('|')
            flashcards[question] = answer
    return flashcards

def quiz():
    flashcards = read_flashcards_from_file('flashcards.txt')
    print("Welcome to the Flashcard App!\n")
    
    # Shuffle the flashcards
    flashcard_keys = list(flashcards.keys())
    random.shuffle(flashcard_keys)
    
    correct_answers = 0
    total_questions = len(flashcards)
    
    for question in flashcard_keys:
        answer = input(f"{question} \nYour answer: ")
        if answer.lower() == flashcards[question].lower():
            print("Correct!\n")
            correct_answers += 1
        else:
            print(f"Wrong! The correct answer is: {flashcards[question]}\n")
    
    print(f"Quiz completed! You got {correct_answers} out of {total_questions} questions correct.")

quiz()